import { App, Editor, MarkdownView, Modal, Notice, Plugin, PluginSettingTab, Setting } from 'obsidian';

export default class Arr0s extends Plugin {
	async onload() {
		this.arrows = {
			"=>": "⟹",
			"<=": "⟸",
			"->": "→",
			"<-": "←",
			"~>": "↝",
			"<~": "↜",
			"O>": "↻"
		}
		
		// This adds a settings tab so the user can configure various aspects of the plugin
		this.addSettingTab(new Arr0sSettingTab(this.app, this));
		
		this.registerEvent(app.workspace.on('editor-change', (editor) => {
			// Get the current document text
			const doc = editor.getDoc();
			const text = doc.getValue();
			var replacedText = text;

			// Perform the text replacement
			for (const [key, value] of Object.entries(this.arrows)) {
				replacedText = replacedText.replace(key, value);
			}

			// Replace the entire document with the replaced text
			if (text !== replacedText) {
				doc.setValue(replacedText);
			}
		}));
	}

	onunload() {

	}
}

class Arr0sSettingTab extends PluginSettingTab {
	plugin: Arr0s;

	constructor(app: App, plugin: Arr0s) {
		super(app, plugin);
		this.plugin = plugin;
	}

	display(): void {
		const {containerEl} = this;

		containerEl.empty();

		containerEl.createEl('h2', {text: 'Arr0s Refrence'});
		
		containerEl.createEl('hr');

		for (const [key, value] of Object.entries(this.plugin.arrows)) {
			containerEl.createEl('li', {text: key + ' replaces to ' + value});
		}
	}
}
